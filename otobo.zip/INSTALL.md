Please see [the installation instructions](https://doc.otobo.org/manual/installation/stable/en/content/index.html)
in the online documentation.
